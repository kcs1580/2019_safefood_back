package edu.ssafy.boot;

import org.springframework.boot.test.context.SpringBootTest;
import org.junit.Test;
@SpringBootTest
class SafeFoodWebSpring광주2오지윤방준영김창수ApplicationTests {

	@Test
	void contextLoads() {
	}

}
