package com.safefood.repository;

public class FoodMyBatisRepositoryImpl {

}
