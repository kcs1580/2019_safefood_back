package com.safefood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeFoodWebSpring광주2오지윤방준영김창수Application {

	public static void main(String[] args) {
		SpringApplication.run(SafeFoodWebSpring광주2오지윤방준영김창수Application.class, args);
	}

}
