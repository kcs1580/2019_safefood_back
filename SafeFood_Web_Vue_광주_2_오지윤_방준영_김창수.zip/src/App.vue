<template>
<div id="app">



<div class='headtitle'>
  <a  href="http://localhost:8090"><img src="../public/ssafy_logo.png"/>  </a>
  <h2>Q&A</h2>
</div>
<div class='search_box'>
  
 <nav>
        <router-link class="btn btn-primary" to="/insertboard">글 등록하기</router-link> |
        <router-link class="btn btn-primary" to="/listBoard">게시판 목록</router-link> |
       
 </nav>
</div>
        <router-view/>
</div>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>

</style>
